package kg.geeks.game.players;

public enum SuperAbility {
    CRITICAL_DAMAGE,
    BOOST,
    HEAL,
    BLOCK_DAMAGE_REVERT,
    EXPLOSION
}
