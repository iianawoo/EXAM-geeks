package kg.geeks.game.general;

public class Lesson_8 {
    public static void main(String[] args) {
        RPG_Game.startGame();
    }
}
